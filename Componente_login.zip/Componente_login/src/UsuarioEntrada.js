import React, {Component}  from 'react';

import UsuarioSaida from './UsuarioSaida';

class UsuarioEntrada extends Component {
  constructor(props) {
    super(props);

    this.state = {
        texto: ''
    };
  }

  handleTextChange(e) {
    this.setState({
      texto: e.target.value
    });
    
  }
  
  render() {
    return (
      <div>
        Digite o nome: <input type="text" onChange={this.handleTextChange.bind(this)}></input>
        <div>
          <UsuarioSaida nome={this.state.texto}/>
            
        </div>

      </div>
        )
    }
}
export default UsuarioEntrada;