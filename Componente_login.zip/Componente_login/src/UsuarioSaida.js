import React, {Component}  from 'react';


const UsuarioSaida = (props) => {

        return (
            <div>
              <h4>O nome digitado foi: <b>{props.nome}</b></h4>

              <p>
                Meu link no github é: https://github.com/bitaraeswit/Desenvolvimento-Front-End
              </p>
            </div>
        );
}
export default UsuarioSaida;