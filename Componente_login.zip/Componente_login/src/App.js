
import './App.css';
import React, {Component} from 'react';

import UsuarioEntrada from './UsuarioEntrada';

class App extends Component{
  render(){
    return (
      <div>
        <UsuarioEntrada />
      </div>
    );
  }
}

export default App;
